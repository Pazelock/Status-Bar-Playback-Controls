# SPDX-License-Identifier: GPL-2.0-or-later
#
# Status Bar Playback Controls
# Copyright (C) 2026 Pazelock

bl_info = {
    "name": "Status Bar Playback Controls",
    "author": "Pazelock",
    "version": (1, 1, 0),
    "blender": (4, 2, 0),
    "category": "Animation",
    "website": "https://extensions.blender.org/add-ons/status-bar-playback-contols",
    "tracker_url": "https://github.com/pazelock/status-bar-playback-controls/issues",
    "doc_url": "https://github.com/Pazelock/Status-Bar-Playback-Controls/blob/main/docs/GUIDE.md",
}

import bpy
from bpy.props import BoolProperty
from bl_ui.space_statusbar import STATUSBAR_HT_header


# ---------------------------------------------------------------------------
# Addon Preferences
# ---------------------------------------------------------------------------

class StatusBarPlaybackPreferences(bpy.types.AddonPreferences):
    bl_idname = __name__

    show_jump_start: BoolProperty(
        name="Jump to First Frame",
        description="Show button: jump to first frame and pause",
        default=True,
    )
    show_prev_keyframe: BoolProperty(
        name="Previous Keyframe",
        description="Show button: jump to previous keyframe",
        default=False,
    )
    show_play_reverse: BoolProperty(
        name="Play in Reverse / Pause",
        description="Show button: play animation in reverse",
        default=False,
    )
    show_play: BoolProperty(
        name="Play / Pause",
        description="Show button: play or pause the animation",
        default=True,
    )
    show_next_keyframe: BoolProperty(
        name="Next Keyframe",
        description="Show button: jump to next keyframe",
        default=False,
    )
    show_jump_end: BoolProperty(
        name="Jump to Last Frame",
        description="Show button: jump to last frame and pause",
        default=True,
    )
    show_frame_input: BoolProperty(
        name="Current Frame Input",
        description="Show the current frame number input field",
        default=True,
    )
    show_cancel_button: BoolProperty(
        name="Animation Player Cancel Button",
        description="Show the built-in animation player cancel button",
        default=False,
    )

    def draw(self, context):
        layout = self.layout
        layout.label(text="Show / hide status bar controls:")
        col = layout.column(align=True)
        col.prop(self, "show_jump_start")
        col.prop(self, "show_prev_keyframe")
        col.prop(self, "show_play_reverse")
        col.prop(self, "show_play")
        col.prop(self, "show_next_keyframe")
        col.prop(self, "show_jump_end")
        col.separator()
        col.prop(self, "show_frame_input")
        col.prop(self, "show_cancel_button")


# ---------------------------------------------------------------------------
# Monkey-patch the status bar draw method
# ---------------------------------------------------------------------------

_original_draw = STATUSBAR_HT_header.draw


def _patched_draw(self, context):
    layout = self.layout
    scene = context.scene
    screen = context.screen
    prefs = context.preferences.addons[__name__].preferences
    playing = screen.is_animation_playing

    layout.template_input_status()
    layout.separator_spacer()
    layout.template_reports_banner()

    # Cancel button
    if prefs.show_cancel_button:
        layout.template_running_jobs()

    # Frame input + playback buttons
    row = layout.row(align=True)

    # Frame field always present so layout never shifts
    if prefs.show_frame_input:
        sub = row.row(align=True)
        sub.ui_units_x = 3.8
        sub.prop(scene, "frame_current", text="")
        row.separator(factor=0.6)

    btn = row.row(align=True)

    if prefs.show_jump_start:
        btn.operator("screen.frame_jump", text="", icon='REW').end = False

    if prefs.show_prev_keyframe:
        btn.operator("screen.keyframe_jump", text="", icon='PREV_KEYFRAME').next = False

    # Reverse play – single button that toggles between PLAY_REVERSE and PAUSE
    if prefs.show_play_reverse:
        if not (scene.sync_mode == 'AUDIO_SYNC' and
                context.preferences.system.audio_device == 'JACK'):
            if playing:
                btn.operator("screen.animation_play", text="", icon='PAUSE').reverse = True
            else:
                btn.operator("screen.animation_play", text="", icon='PLAY_REVERSE').reverse = True

    # Forward play – single button that toggles between PLAY and PAUSE
    if prefs.show_play:
        if playing:
            btn.operator("screen.animation_play", text="", icon='PAUSE')
        else:
            btn.operator("screen.animation_play", text="", icon='PLAY')

    if prefs.show_next_keyframe:
        btn.operator("screen.keyframe_jump", text="", icon='NEXT_KEYFRAME').next = True

    if prefs.show_jump_end:
        btn.operator("screen.frame_jump", text="", icon='FF').end = True

    # ──────────────────────────────────────────────────────────────────────

    layout.separator_spacer()

    row = layout.row()
    row.alignment = 'RIGHT'
    row.label(text=screen.statusbar_info(), translate=False)


# ---------------------------------------------------------------------------
# Timer – tag every area for redraw on every tick so frame counter is live
# ---------------------------------------------------------------------------

def _redraw_timer():
    try:
        for window in bpy.context.window_manager.windows:
            for area in window.screen.areas:
                area.tag_redraw()
    except Exception:
        pass
    return 0.0   # 0.0 = re-fire as fast as Blender allows (each draw tick)


# ---------------------------------------------------------------------------
# Keymap – bind Space in the STATUSBAR keymap
# ---------------------------------------------------------------------------

addon_keymaps = []


def register_keymaps():
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if not kc:
        return
    km = kc.keymaps.new(name='Status Bar', space_type='STATUSBAR')
    kmi = km.keymap_items.new(
        idname='screen.animation_play',
        type='SPACE',
        value='PRESS',
    )
    addon_keymaps.append((km, kmi))


def unregister_keymaps():
    for km, kmi in addon_keymaps:
        try:
            km.keymap_items.remove(kmi)
        except Exception:
            pass
    addon_keymaps.clear()


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

classes = (
    StatusBarPlaybackPreferences,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    STATUSBAR_HT_header.draw = _patched_draw
    register_keymaps()

    if not bpy.app.timers.is_registered(_redraw_timer):
        bpy.app.timers.register(_redraw_timer, persistent=True)


def unregister():
    if bpy.app.timers.is_registered(_redraw_timer):
        bpy.app.timers.unregister(_redraw_timer)
    unregister_keymaps()
    STATUSBAR_HT_header.draw = _original_draw

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
