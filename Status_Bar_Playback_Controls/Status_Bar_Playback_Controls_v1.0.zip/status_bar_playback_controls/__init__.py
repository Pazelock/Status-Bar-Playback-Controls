# SPDX-License-Identifier: GPL-2.0-or-later
#
# Status Bar Playback Controls
# Copyright (C) 2026 Pazelock
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

bl_info = {
    "name": "Status Bar Playback Controls",
    "author": "Pazelock",
    "version": (1, 0, 0),
    "blender": (4, 2, 0),
    "category": "Animation",
    "website": "https://extensions.blender.org/add-ons/status-bar-playback-contols",
    "tracker_url": "https://github.com/pazelock/status-bar-playback-controls/issues",
    "doc_url": "https://github.com/Pazelock/Status-Bar-Playback-Controls/blob/main/docs/GUIDE.md",
}

import bpy
from bpy.props import BoolProperty, IntProperty
from bl_ui.space_statusbar import STATUSBAR_HT_header


# ---------------------------------------------------------------------------
# Addon Preferences
# ---------------------------------------------------------------------------

class BottomBarPlaybackPreferences(bpy.types.AddonPreferences):
    bl_idname = __name__

    show_rew: BoolProperty(
        name="Jump to First Frame & Pause",
        description="Show the REW button (jump to first frame and pause)",
        default=True,
    )
    show_play_from_start: BoolProperty(
        name="Jump to First Frame & Play",
        description="Show the Play-from-Start button (jump to first frame and play)",
        default=True,
    )
    show_ff: BoolProperty(
        name="Jump to Last Frame & Pause",
        description="Show the FF button (jump to last frame and pause)",
        default=True,
    )
    show_frame_input: BoolProperty(
        name="Current Frame Input",
        description="Show the current frame number input field",
        default=True,
    )

    def draw(self, context):
        layout = self.layout
        layout.label(text="Show / hide bottom bar controls:")
        col = layout.column(align=True)
        col.prop(self, "show_rew")
        col.prop(self, "show_play_from_start")
        col.prop(self, "show_ff")
        col.prop(self, "show_frame_input")


# ---------------------------------------------------------------------------
# Operators
# ---------------------------------------------------------------------------

class SCREEN_OT_jump_to_first_frame_pause(bpy.types.Operator):
    """Stop playback and jump to the first frame"""
    bl_idname = "screen.jump_to_first_frame_pause"
    bl_label = "Jump to First Frame and Pause"
    bl_description = "Jump to the first frame and pause playback"
    bl_options = {'REGISTER'}

    def execute(self, context):
        if context.screen.is_animation_playing:
            bpy.ops.screen.animation_cancel(restore_frame=False)
        context.scene.frame_set(context.scene.frame_start)
        return {'FINISHED'}


class SCREEN_OT_jump_to_first_frame(bpy.types.Operator):
    """Jump to first frame and resume playback"""
    bl_idname = "screen.jump_to_first_frame"
    bl_label = "Jump to First Frame and Play"
    bl_description = "Jump to the first frame and resume playback"
    bl_options = {'REGISTER'}

    def execute(self, context):
        if context.screen.is_animation_playing:
            bpy.ops.screen.animation_cancel(restore_frame=False)
        context.scene.frame_set(context.scene.frame_start)
        bpy.ops.screen.animation_play()
        return {'FINISHED'}


class SCREEN_OT_jump_to_last_frame_pause(bpy.types.Operator):
    """Stop playback and jump to the last frame"""
    bl_idname = "screen.jump_to_last_frame_pause"
    bl_label = "Jump to Last Frame and Pause"
    bl_description = "Jump to the last frame and pause playback"
    bl_options = {'REGISTER'}

    def execute(self, context):
        if context.screen.is_animation_playing:
            bpy.ops.screen.animation_cancel(restore_frame=False)
        context.scene.frame_set(context.scene.frame_end)
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# Monkey-patch the status bar draw method
# ---------------------------------------------------------------------------

_original_draw = STATUSBAR_HT_header.draw


def _patched_draw(self, context):
    layout = self.layout

    prefs = context.preferences.addons[__name__].preferences

    layout.template_input_status()
    layout.separator_spacer()
    layout.template_reports_banner()
    layout.template_running_jobs()

    # ── Playback controls + frame input ───────────────────────────────────
    playing = context.screen.is_animation_playing
    show_any = (
        (prefs.show_rew and playing) or
        (prefs.show_play_from_start and playing) or
        (prefs.show_ff and playing) or
        prefs.show_frame_input
    )

    if show_any:
        row = layout.row(align=True)
        row.separator(factor=0.8)

        if prefs.show_rew and playing:
            row.operator("screen.jump_to_first_frame_pause", text="", icon='REW')

        if prefs.show_play_from_start and playing:
            row.operator("screen.jump_to_first_frame", text="", icon='FRAME_NEXT')

        if prefs.show_ff and playing:
            row.operator("screen.jump_to_last_frame_pause", text="", icon='FF')

        if prefs.show_frame_input:
            # Small gap between buttons and frame field
            if playing:
                row.separator(factor=1.0)
            # prop() on scene.frame_current gives us a live-updating,
            # draggable, typeable integer field — identical to the timeline.
            sub = row.row(align=True)
            sub.ui_units_x = 4.0
            sub.prop(context.scene, "frame_current", text="")
    # ──────────────────────────────────────────────────────────────────────

    layout.separator_spacer()

    row = layout.row()
    row.alignment = 'RIGHT'
    row.label(text=context.screen.statusbar_info(), translate=False)


# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# Timer-based redraw – polls every frame tick during playback
# ---------------------------------------------------------------------------

def _redraw_timer():
    """Registered as a persistent timer. Forces the status bar to redraw
    on every tick so frame_current updates in real time during playback.
    Blender's frame_change_post handler is unreliable during the animation
    player loop, so a timer is the only robust solution.
    """
    try:
        for window in bpy.context.window_manager.windows:
            for area in window.screen.areas:
                area.tag_redraw()
    except Exception:
        pass
    return 1 / 60  # re-run ~60 times per second


# ---------------------------------------------------------------------------
# Keymap – bind Space in the STATUSBAR keymap
# ---------------------------------------------------------------------------

addon_keymaps = []


def register_keymaps():
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if not kc:
        return

    km = kc.keymaps.new(name='Status Bar', space_type='STATUSBAR')
    kmi = km.keymap_items.new(
        idname='screen.animation_play',
        type='SPACE',
        value='PRESS',
    )
    addon_keymaps.append((km, kmi))


def unregister_keymaps():
    for km, kmi in addon_keymaps:
        try:
            km.keymap_items.remove(kmi)
        except Exception:
            pass
    addon_keymaps.clear()


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

classes = (
    BottomBarPlaybackPreferences,
    SCREEN_OT_jump_to_first_frame_pause,
    SCREEN_OT_jump_to_first_frame,
    SCREEN_OT_jump_to_last_frame_pause,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    STATUSBAR_HT_header.draw = _patched_draw
    register_keymaps()
    # Use a persistent timer to force redraws – more reliable than
    # frame_change_post which doesn't fire consistently during playback
    if not bpy.app.timers.is_registered(_redraw_timer):
        bpy.app.timers.register(_redraw_timer, persistent=True)


def unregister():
    if bpy.app.timers.is_registered(_redraw_timer):
        bpy.app.timers.unregister(_redraw_timer)
    unregister_keymaps()
    STATUSBAR_HT_header.draw = _original_draw

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
